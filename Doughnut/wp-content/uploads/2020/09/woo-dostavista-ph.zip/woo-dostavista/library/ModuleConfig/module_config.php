<?php

return [
    'country' => 'ph',
    'dv_cms_module_api_test_url' => 'https://robotapitest.mrspeedy.ph/api/cms-module',
    'dv_cms_module_api_prod_url' => 'https://robot.mrspeedy.ph/api/cms-module',
];
