<?php

namespace WooDostavista\DvCmsModuleApiClient\Request;

interface PointRequestModelInterface
{
    public function getRequestData(): array;
}
