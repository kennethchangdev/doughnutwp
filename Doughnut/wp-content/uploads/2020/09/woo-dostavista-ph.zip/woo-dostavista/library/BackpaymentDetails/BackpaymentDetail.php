<?php

namespace WooDostavista\BackpaymentDetails;

class BackpaymentDetail
{
    /** @var int|null */
    public $id;

    /** @var string */
    public $description;
}
